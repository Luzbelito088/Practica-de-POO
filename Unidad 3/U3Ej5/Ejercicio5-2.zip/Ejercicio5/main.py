from ClaseGestorMedio import GestorMedio
from ClaseTelevision import Television

if __name__=='__main__':
    unGestorMedio=GestorMedio()
    unGestorMedio.cargar()
    unGestorMedio.mostrarMedios()
    unaTelevision=Television("TV PUBLICA",4,15000,1)
    unGestorMedio.agregarfinal(unaTelevision)
    unGestorMedio.mostrarMedios()
    unGestorMedio.contar()